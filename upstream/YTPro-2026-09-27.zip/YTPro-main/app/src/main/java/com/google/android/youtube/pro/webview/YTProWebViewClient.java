package com.google.android.youtube.pro.webview;

import android.content.Intent;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.youtube.pro.ForegroundService;
import com.google.android.youtube.pro.MainActivity;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import android.util.Log;

public class YTProWebViewClient extends WebViewClient {
	
	private final MainActivity activity;
	private final YTProWebView web;
	
	public YTProWebViewClient(MainActivity activity, YTProWebView web) {
		this.activity = activity;
		this.web = web;
	}
	
	@Override
	public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
		String url = request.getUrl().toString();

		if (url.contains("accounts.google.com") ||
    url.contains("myaccount.google.com") ||
    url.contains("accounts.youtube.com") || 
    url.contains("google.com/signin") ||
    url.contains("google.com/oauth") ||
    url.contains("googleapis.com/oauth") ||
    url.contains("/signin") ||              
    url.contains("SetSID")) {             
        return super.shouldInterceptRequest(view, request);
}

		
		if (request.isForMainFrame() && (url.contains("m.youtube.com") || url.contains("www.youtube.com"))) {
			try {
				URL newUrl = new URL(url);
				HttpsURLConnection connection = (HttpsURLConnection) newUrl.openConnection();
				connection.setRequestMethod(request.getMethod());
				
				for (Map.Entry<String, String> header : request.getRequestHeaders().entrySet()) {
					if (!header.getKey().equalsIgnoreCase("Accept-Encoding")) {
						connection.setRequestProperty(header.getKey(), header.getValue());
					}
				}
				
				String cookies = android.webkit.CookieManager.getInstance().getCookie(url);
				if (cookies != null) connection.setRequestProperty("Cookie", cookies);
				
				connection.connect();
				
				Map<String, String> safeHeaders = new HashMap<>();
				for (Map.Entry<String, List<String>> entry : connection.getHeaderFields().entrySet()) {
					if (entry.getKey() != null) {
						String headerName = entry.getKey().toLowerCase();
						if (!headerName.equals("content-security-policy") && !headerName.equals("content-security-policy-report-only")) {
							safeHeaders.put(entry.getKey(), String.join(", ", entry.getValue()));
						}
					}
				}
				
				InputStream is = connection.getInputStream();
				BufferedReader reader = new BufferedReader(new InputStreamReader(is));
				StringBuilder html = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					if (line.toLowerCase().contains("content-security-policy")) {
						line = line.replaceAll("<meta.*?http-equiv=[\"']?Content-Security-Policy[\"']?.*?>", "");
					}
					html.append(line).append("\n");
				}
				
				InputStream modifiedHtmlStream = new ByteArrayInputStream(html.toString().getBytes("UTF-8"));
				return new WebResourceResponse("text/html", "utf-8", connection.getResponseCode(), "OK", safeHeaders, modifiedHtmlStream);
				
			} catch (Exception e) {
				return super.shouldInterceptRequest(view, request);
			}
		}
		
		
		if (url.startsWith("https://www.google.com/js/") || 
		url.startsWith("https://www.google.com/recaptcha/") ||
		url.startsWith("https://www.google.com/js/th/")) {
			
			try {
				HttpsURLConnection conn = (HttpsURLConnection) new URL(url).openConnection();
				conn.setRequestProperty("User-Agent", request.getRequestHeaders().get("User-Agent"));
				conn.setRequestProperty("Referer", "https://www.youtube.com/");
				conn.setInstanceFollowRedirects(true);
				conn.setConnectTimeout(10000);
				conn.setReadTimeout(10000);
				conn.connect();
				
				String mimeType = conn.getContentType();
				String encoding = conn.getContentEncoding();
				if (encoding == null) encoding = "utf-8";
				if (mimeType == null) mimeType = "application/javascript";
				
				Map<String, String> headers = new HashMap<>();
				headers.put("Access-Control-Allow-Origin", "*");
				headers.put("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
				headers.put("Access-Control-Allow-Headers", "*");
				headers.put("Cross-Origin-Resource-Policy", "cross-origin");
				
				return new WebResourceResponse(
				mimeType, encoding,
				conn.getResponseCode(), "OK",
				headers, conn.getInputStream()
				);
				
			} catch (Exception e) {
				Log.e("YTPRO_WVC", "Google JS fetch failed: " + e.getMessage());
			}
		}
		
		
		if (url.contains("youtube.com/ytpro_cdn/")) {
			String modifiedUrl = url;
			if (url.contains("youtube.com/ytpro_cdn/esm")) modifiedUrl = url.replace("youtube.com/ytpro_cdn/esm", "esm.sh");
			else if (url.contains("youtube.com/ytpro_cdn/npm")) modifiedUrl = url.replace("youtube.com/ytpro_cdn", "cdn.jsdelivr.net");
			
			try {
				URL newUrl = new URL(modifiedUrl);
				HttpsURLConnection connection = (HttpsURLConnection) newUrl.openConnection();
                
				connection.setUseCaches(false);
                connection.setDefaultUseCaches(false);
                connection.addRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
                connection.addRequestProperty("Pragma", "no-cache");
                connection.addRequestProperty("Expires", "0");
                connection.setRequestProperty("User-Agent", "YTPRO");
                connection.setRequestProperty("Accept", "**");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                
                connection.setRequestMethod("GET");
				connection.connect();
				
				String mimeType = connection.getContentType() != null ? connection.getContentType() : "application/javascript";
				String encoding = connection.getContentEncoding() != null ? connection.getContentEncoding() : "utf-8";
				
				if (encoding == null) encoding = "utf-8";
                String contentType = connection.getContentType();
                if (contentType == null) {
                    contentType = "application/javascript";
                }

                Map<String, String> headers = new HashMap<>();
                headers.put("Access-Control-Allow-Origin", "*");
                headers.put("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
                headers.put("Access-Control-Allow-Headers", "*");
                headers.put("Content-Type", contentType);
                headers.put("Access-Control-Allow-Credentials", "true");
                headers.put("Cross-Origin-Resource-Policy", "cross-origin");
                
                
				if (request.getMethod().equals("OPTIONS")) {
					return new WebResourceResponse("text/plain", "UTF-8", 204, "No Content", headers, null);
				}
				
				return new WebResourceResponse(mimeType, encoding, connection.getResponseCode(), "OK", headers, connection.getInputStream());
			} catch (Exception e) {
				return super.shouldInterceptRequest(view, request);
			}
		}
		
		return super.shouldInterceptRequest(view, request);
	}
	
	@Override
	public void onPageFinished(WebView view, String url) {
		web.evaluateJavascript("if (window.trustedTypes && window.trustedTypes.createPolicy && !window.trustedTypes.defaultPolicy) {window.trustedTypes.createPolicy('default', {createHTML: (string) => string,createScriptURL: string => string, createScript: string => string, });}", null);
		web.evaluateJavascript("(function () { var script = document.createElement('script'); script.src='https://youtube.com/ytpro_cdn/npm/ytpro@latest'; document.body.appendChild(script);  })();", null);
		web.evaluateJavascript("(function () { var script = document.createElement('script'); script.src='https://youtube.com/ytpro_cdn/npm/ytpro@latest/bgplay.js'; document.body.appendChild(script);  })();", null);
		web.evaluateJavascript("(function () { var script = document.createElement('script');script.type='module';script.src='https://youtube.com/ytpro_cdn/npm/ytpro@latest/innertube.js'; document.body.appendChild(script);  })();", null);
		
		
		
		
		if (!url.contains("youtube.com/watch") && !url.contains("youtube.com/shorts") && activity.isPlaying) {
			activity.isPlaying = false;
			activity.mediaSession = false;
			activity.stopService(new Intent(activity.getApplicationContext(), ForegroundService.class));
		}
		super.onPageFinished(view, url);
	}
}
